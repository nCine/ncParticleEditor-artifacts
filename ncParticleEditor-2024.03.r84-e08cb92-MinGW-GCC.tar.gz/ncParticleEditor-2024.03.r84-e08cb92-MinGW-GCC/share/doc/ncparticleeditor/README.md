[![Linux](https://github.com/nCine/ncParticleEditor/workflows/Linux/badge.svg)](https://github.com/nCine/ncParticleEditor/actions?workflow=Linux)
[![macOS](https://github.com/nCine/ncParticleEditor/workflows/macOS/badge.svg)](https://github.com/nCine/ncParticleEditor/actions?workflow=macOS)
[![Windows](https://github.com/nCine/ncParticleEditor/workflows/Windows/badge.svg)](https://github.com/nCine/ncParticleEditor/actions?workflow=Windows)
[![MinGW](https://github.com/nCine/ncParticleEditor/workflows/MinGW/badge.svg)](https://github.com/nCine/ncParticleEditor/actions?workflow=MinGW)
[![Emscripten](https://github.com/nCine/ncParticleEditor/workflows/Emscripten/badge.svg)](https://github.com/nCine/ncParticleEditor/actions?workflow=Emscripten)
[![Android](https://github.com/nCine/ncParticleEditor/workflows/Android/badge.svg)](https://github.com/nCine/ncParticleEditor/actions?workflow=Android)
[![CodeQL](https://github.com/nCine/ncParticleEditor/workflows/CodeQL/badge.svg)](https://github.com/nCine/ncParticleEditor/actions?workflow=CodeQL)


# ncParticleEditor
ncParticleEditor is a particle editor made with the nCine.  
