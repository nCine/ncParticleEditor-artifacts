# ncParticleEditor
ncParticleEditor is a particle editor made with the nCine.  
